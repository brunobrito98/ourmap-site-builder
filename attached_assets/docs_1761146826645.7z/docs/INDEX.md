# 📚 Índice Completo da Documentação

Bem-vindo à documentação completa da plataforma de eventos! Aqui você encontrará todos os recursos organizados para fácil navegação.

## 🚀 Começando

### Para Novos Usuários
1. **[Guia de Início Rápido](INICIO-RAPIDO.md)**
   - Criar conta
   - Primeiro evento
   - Configurações básicas
   - Dicas essenciais

### Para Usuários Existentes
2. **[Manual Completo do Usuário](manuais/MANUAL-USUARIO.md)**
   - Todas as funcionalidades detalhadas
   - Casos de uso
   - FAQ completo
   - Troubleshooting

## 👥 Para Usuários

### Eventos
- **[Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md)**
  - Configuração Stripe
  - Tipos de ingressos
  - Lotes progressivos
  - Gestão de vendas
  - Check-in

- **[Eventos Recorrentes](tutoriais/eventos-recorrentes.md)**
  - Configurar recorrência
  - Padrões (diário, semanal, mensal)
  - Gerenciar séries
  - Casos de uso

### Promoção
- **[Sistema de Boost](tutoriais/boost-eventos.md)**
  - O que é boost
  - Planos disponíveis
  - Como ativar
  - Melhores práticas
  - ROI e métricas

- **[Programa de Referência](tutoriais/programa-referencia.md)**
  - Ganhar créditos
  - Compartilhar link
  - Usar créditos em boosts
  - Estratégias de crescimento

### Social
- **[Grupos e Comunidades](tutoriais/grupos-comunidades.md)**
  - Encontrar grupos
  - Participar de discussões
  - Criar enquetes
  - Criar seu próprio grupo
  - Moderar comunidade

- **Chat e Mensagens** *(em breve)*
  - Conversar com amigos
  - Configurações de privacidade
  - Notificações

- **Sistema de Amizades** *(em breve)*
  - Fazer amigos
  - Seguir pessoas
  - Conexões

### Perfil e Conta
- **Personalização de Perfil** *(em breve)*
  - Foto e galeria
  - Bio e localização
  - Redes sociais
  - Configurações de privacidade

- **Segurança e Privacidade** *(em breve)*
  - Controles de visibilidade
  - Privacidade de mensagens
  - Dados pessoais
  - Exclusão de conta

## 🛡️ Para Administradores

- **[Manual do Administrador](admin/MANUAL-ADMINISTRADOR.md)**
  - Dashboard e métricas
  - Gerenciamento de usuários
  - Moderação de conteúdo
  - Gestão de eventos
  - Sistema de boost
  - Categorias
  - Relatórios e analytics

## 📖 Referência

### Funcionalidades por Categoria

#### Eventos
- Criar eventos (gratuitos, pagos, vaquinha)
- Eventos públicos e privados
- Eventos recorrentes
- Limite de participantes
- Lista de espera
- Convidados especiais
- Galeria de fotos
- Avaliações

#### Pagamentos
- Stripe integration
- Múltiplos tipos de ingresso
- Lotes progressivos
- Multi-currency (BRL/USD)
- QR Codes automáticos
- Reembolsos
- Vaquinha/Crowdfunding

#### Social
- Sistema de amizades
- Chat privado
- Grupos temáticos
- Enquetes em grupos
- Feed de atividades
- Notificações

#### Promoção
- Boost de eventos (Prata, Ouro, Diamante)
- Programa de referência
- Sistema de créditos
- Analytics e métricas

#### Localização
- Mapbox integration
- Busca por proximidade
- Geolocalização automática
- Visualização em mapa

#### Notificações
- Push notifications (Firebase)
- Email notifications (SendGrid)
- Configurações granulares
- Multi-idioma

#### Moderação
- Sistema automático
- Blocklist
- Trust score
- Denúncias
- Painel admin

## 🎯 Guias por Objetivo

### "Quero organizar eventos..."

**Gratuitos:**
1. [Início Rápido](INICIO-RAPIDO.md) → Seção "Criar seu Primeiro Evento"
2. [Manual do Usuário](manuais/MANUAL-USUARIO.md) → Seção "Eventos"

**Pagos com Ingressos:**
1. [Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md)
2. [Manual do Usuário](manuais/MANUAL-USUARIO.md) → "Pagamentos"

**Recorrentes (Aulas, Meetups):**
1. [Eventos Recorrentes](tutoriais/eventos-recorrentes.md)

**Com Vaquinha:**
1. [Manual do Usuário](manuais/MANUAL-USUARIO.md) → "Eventos" → "Vaquinha"

### "Quero promover meu evento..."

1. [Sistema de Boost](tutoriais/boost-eventos.md)
2. [Programa de Referência](tutoriais/programa-referencia.md) → Para ganhar créditos

### "Quero encontrar eventos..."

1. [Início Rápido](INICIO-RAPIDO.md) → "Explorar Eventos"
2. [Manual do Usuário](manuais/MANUAL-USUARIO.md) → "Descobrir Eventos"

### "Quero participar de comunidades..."

1. [Grupos e Comunidades](tutoriais/grupos-comunidades.md)

### "Quero ganhar dinheiro com eventos..."

1. [Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md)
2. [Sistema de Boost](tutoriais/boost-eventos.md) → "ROI"
3. [Eventos Recorrentes](tutoriais/eventos-recorrentes.md) → "Casos de Uso"

### "Sou administrador..."

1. [Manual do Administrador](admin/MANUAL-ADMINISTRADOR.md)

## 💡 Tutoriais em Desenvolvimento

Próximos guias que serão adicionados:

- [ ] Chat e Mensagens Privadas
- [ ] Sistema de Amizades e Networking
- [ ] Personalização Avançada de Perfil
- [ ] Segurança e Privacidade
- [ ] Eventos com Convidados VIP
- [ ] Galeria Colaborativa de Fotos
- [ ] Analytics Avançado
- [ ] Estratégias de Marketing para Eventos
- [ ] Casos de Sucesso
- [ ] Mobile App (PWA)

## 🔍 Busca Rápida

### Por Palavra-Chave

**Boost:** [Sistema de Boost](tutoriais/boost-eventos.md)  
**Créditos:** [Programa de Referência](tutoriais/programa-referencia.md)  
**Ingresso:** [Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md)  
**Recorrente:** [Eventos Recorrentes](tutoriais/eventos-recorrentes.md)  
**Grupo:** [Grupos e Comunidades](tutoriais/grupos-comunidades.md)  
**Admin:** [Manual do Administrador](admin/MANUAL-ADMINISTRADOR.md)  
**Moderação:** [Manual do Administrador](admin/MANUAL-ADMINISTRADOR.md) → "Sistema de Moderação"  
**Stripe:** [Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md)  
**QR Code:** [Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md) → "Check-in"

## 📊 Documentação Técnica

Para desenvolvedores:
- **[README.md](../README.md)** - Visão geral técnica
- **[replit.md](../replit.md)** - Arquitetura e decisões de design
- Schema do banco: `shared/schema.ts`
- API Routes: `server/routes.ts`

## ❓ Perguntas Frequentes Gerais

**Q: Onde encontro informações sobre preços?**  
R: [Sistema de Boost](tutoriais/boost-eventos.md) para promoção de eventos e [Criar Eventos Pagos](tutoriais/criar-eventos-pagos.md) para venda de ingressos.

**Q: Como ganho créditos grátis?**  
R: [Programa de Referência](tutoriais/programa-referencia.md)

**Q: Posso criar eventos que se repetem?**  
R: Sim! [Eventos Recorrentes](tutoriais/eventos-recorrentes.md)

**Q: Como funciona a moderação?**  
R: [Manual do Administrador](admin/MANUAL-ADMINISTRADOR.md) → "Sistema de Moderação"

**Q: Onde vejo todas as funcionalidades?**  
R: [Manual Completo do Usuário](manuais/MANUAL-USUARIO.md)

## 📞 Suporte

**Não encontrou o que procura?**

- 💬 Chat em tempo real (disponível na plataforma)
- 📧 Email: suporte@plataforma.com
- 📖 FAQ: [Manual do Usuário](manuais/MANUAL-USUARIO.md#perguntas-frequentes)

## 🔄 Atualizações

Esta documentação é atualizada regularmente. Última atualização: **Outubro 2025**

Sugestões de melhorias são bem-vindas!

---

**Dica:** Use `Ctrl+F` (ou `Cmd+F` no Mac) para buscar palavras-chave específicas dentro de cada documento.
