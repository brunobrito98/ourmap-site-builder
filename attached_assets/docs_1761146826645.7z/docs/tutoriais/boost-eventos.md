# 🎯 Tutorial: Sistema de Boost de Eventos

## O que é o Sistema de Boost?

O Boost é uma ferramenta poderosa para promover seus eventos e alcançar muito mais pessoas. Quando você ativa um boost, seu evento:

- 📊 Aparece nas primeiras posições das buscas
- 🔝 É destacado na tela inicial
- 📍 Ganha mais visibilidade em buscas por localização
- 🎯 Alcança usuários com interesses relacionados

## Como Funciona?

### Distribuição Inteligente

Ao contrário de sistemas que mostram seu evento apenas uma vez, nosso sistema distribui a visibilidade ao longo do tempo:

1. **Você compra um plano** com X "subidas"
2. **Sistema agenda automaticamente** as subidas ao longo do período
3. **Seu evento é promovido** regularmente durante todo o período
4. **Máxima exposição** sem picos e quedas

### Exemplo Prático

**Plano Ouro (50 subidas em 14 dias):**
- Dia 1: 4 subidas
- Dia 2: 3 subidas  
- Dia 3: 4 subidas
- ... continua até o dia 14
- **+ 10 aparições especiais no topo**

Isso significa que durante 2 semanas, seu evento será constantemente promovido!

## Planos Disponíveis

### 🥈 Prata - Iniciante
**R$ 29,90 / $9.90 USD**

✅ Ideal para:
- Eventos locais pequenos
- Primeira experiência com boost
- Orçamento limitado

📊 Benefícios:
- 20 subidas ao longo de 7 dias
- ~3 subidas por dia
- Destaque moderado

### 🥇 Ouro - Recomendado
**R$ 69,90 / $19.90 USD**

✅ Ideal para:
- Eventos médios
- Alcance regional
- Melhor custo-benefício

📊 Benefícios:
- 50 subidas ao longo de 14 dias
- ~4 subidas por dia
- 10 aparições no topo absoluto
- Destaque forte

### 💎 Diamante - Premium
**R$ 149,90 / $39.90 USD**

✅ Ideal para:
- Grandes eventos
- Festivais e conferências
- Alcance nacional/internacional

📊 Benefícios:
- 100 subidas ao longo de 30 dias
- ~3 subidas por dia durante 1 mês
- 30 aparições no topo absoluto
- Máxima visibilidade

## Passo a Passo: Ativar Boost

### 1. Acesse seu Evento

1. Vá para **Perfil**
2. Clique em **Meus Eventos**
3. Selecione o evento que deseja promover

### 2. Escolha o Plano

1. No detalhes do evento, clique em **"Promover Evento"**
2. Veja as opções de planos
3. Compare benefícios e preços
4. Selecione o plano ideal

### 3. Complete o Pagamento

1. Clique em **"Ativar Boost"**
2. Você será redirecionado para o Stripe
3. Insira dados do cartão ou escolha PIX
4. Confirme o pagamento

### 4. Acompanhe os Resultados

Após ativação:
- ✅ Seu evento estará marcado como "Promovido"
- 📊 Acompanhe visualizações em tempo real
- 📈 Veja estatísticas de crescimento
- ⏱️ Monitore próximas "subidas" programadas

## Usar Créditos de Referência

Tem créditos do programa de referência? Use para pagar o boost!

### Como Aplicar Créditos

1. Na tela de escolha do plano
2. Veja seu **saldo disponível**
3. Marque **"Usar Créditos"**
4. Sistema calcula automaticamente:
   - Se tiver saldo total: **Grátis!**
   - Se tiver saldo parcial: **Paga só a diferença**

### Exemplo

Você tem R$ 40,00 em créditos e quer o Plano Ouro (R$ 69,90):
- Créditos usados: R$ 40,00
- Você paga: R$ 29,90
- Economia: 57%!

## Melhores Práticas

### ⏰ Quando Ativar o Boost?

**Timing Ideal:**
- **1-2 semanas antes do evento:** Para eventos locais
- **3-4 semanas antes:** Para eventos grandes
- **Logo após criar:** Para eventos recorrentes

**Evite:**
- ❌ Ativar boost faltando poucos dias
- ❌ Boost em evento que já lotou
- ❌ Múltiplos boosts no mesmo evento (desperdício)

### 📸 Prepare seu Evento Antes

Para maximizar conversões do boost:

1. **Foto de Capa Atraente**
   - Alta qualidade (mínimo 1200x630px)
   - Representa bem o evento
   - Texto legível se houver

2. **Descrição Completa**
   - O que esperar
   - Programação detalhada
   - Benefícios claros

3. **Informações Precisas**
   - Local exato no mapa
   - Horário correto
   - Categoria adequada

4. **Preço Competitivo**
   - Pesquise eventos similares
   - Considere público-alvo
   - Ofereça lotes promocionais

### 📊 Acompanhe Métricas

Durante o boost, monitore:
- **Visualizações:** Quantas pessoas viram
- **Taxa de Conversão:** Visualizações → Confirmações
- **Origem:** De onde vêm os participantes
- **Horários:** Quando há mais interesse

### 🔄 Otimize Durante o Boost

Se perceber baixa conversão:
- Atualize a descrição
- Melhore a foto de capa
- Ajuste preço (se aplicável)
- Adicione palestrantes/atrações

## ROI - Retorno sobre Investimento

### Calculando seu ROI

Para evento pago, calcule se o boost vale a pena:

**Exemplo:**
- Plano Ouro: R$ 69,90
- Ingresso: R$ 50,00
- Participantes atuais: 20
- Meta: 50 participantes

**Cálculo:**
- Precisa de +30 participantes
- 30 × R$ 50 = R$ 1.500
- Custo boost: R$ 69,90
- **ROI: R$ 1.430 de lucro extra**

Precisaria de apenas **2 vendas extras** para pagar o boost!

### Para Eventos Gratuitos

Benefícios não-monetários:
- 🌟 **Reputação:** Eventos cheios = organizador renomado
- 📈 **Crescimento:** Mais seguidores
- 💼 **Network:** Conhecer mais pessoas
- 🎯 **Impacto:** Sua mensagem alcança mais gente

## Perguntas Frequentes

**Q: Posso cancelar um boost ativo?**  
R: Não, mas você pode pausar a criação de novos eventos promovidos. Boosts já pagos serão completados.

**Q: O que acontece se eu cancelar o evento com boost ativo?**  
R: O boost é automaticamente pausado. Não há reembolso do boost, apenas dos ingressos vendidos.

**Q: Posso transferir boost de um evento para outro?**  
R: Não. Cada boost é específico para um evento.

**Q: Existe limite de quantos boosts posso comprar?**  
R: Não! Mas recomendamos 1 boost por evento para melhor eficiência.

**Q: Como sei se o boost está funcionando?**  
R: No painel do evento, veja o indicador "Promovido" e acompanhe estatísticas de visualização.

**Q: Posso boost em eventos privados?**  
R: Tecnicamente sim, mas não faz sentido. Boost é para aumentar descoberta pública.

**Q: O boost garante lotação?**  
R: Não. Boost aumenta visibilidade, mas qualidade do evento define participação.

**Q: Funciona para eventos em qualquer cidade?**  
R: Sim! O algoritmo prioriza mostrar para pessoas da sua região, mas também alcança interessados em outras áreas.

## Suporte

Problemas com boost? Entre em contato:
- Email: suporte@plataforma.com
- Chat: Disponível em Configurações > Ajuda

---

**Próximos Passos:**
- 📖 Leia sobre [Programa de Referência](./programa-referencia.md)
- 🎯 Aprenda a [Criar Eventos de Sucesso](./criar-eventos-sucesso.md)
- 📊 Descubra [Métricas e Analytics](./metricas-eventos.md)
