# 🔔 Tutorial: Sistema de Notificações

## Visão Geral

Nossa plataforma oferece um sistema completo de notificações para manter você sempre informado sobre:
- 🎉 Novos eventos na sua área
- 👥 Atividade de amigos
- 💬 Novas mensagens
- ✅ Confirmações nos seus eventos
- ⭐ Avaliações recebidas
- 📢 Atualizações de grupos

## Tipos de Notificações

### 📱 Push Notifications (Instantâneas)

Aparecem no seu dispositivo em tempo real, mesmo com app fechado.

**Categorias:**
- **Eventos:** Novos na área, lembretes, cancelamentos
- **Social:** Convites de amizade, mensagens, confirmações
- **Grupos:** Novos posts, enquetes, membros
- **Seus Eventos:** Novos participantes, avaliações

**Exemplo:**
```
🎉 Novo evento próximo a você
"Show de Rock - Bar Central"
Sexta, 22h • 2.3 km de você
```

### 📧 Email Notifications

Emails periódicos ou transacionais.

**Frequências:**
- **Imediato:** Logo após ação acontecer
- **Diário:** Resumo 1x por dia (7h da manhã)
- **Semanal:** Resumo 1x por semana (segunda, 9h)
- **Nunca:** Desativar completamente

**Tipos de Email:**
- Confirmações (ingresso, cadastro)
- Lembretes de eventos
- Resumos de eventos locais
- Atividade de amigos
- Mensagens (se ativado)

## Configurar Notificações

### Acesso às Configurações

1. Vá para **Perfil** (menu inferior)
2. Toque em **Configurações**
3. Selecione **Notificações**

### Configurações de Push

#### Eventos

**Novos Eventos Locais**
- ✅ Ativado: Receba quando evento novo for criado na sua região
- Frequência: Máximo 3 por dia
- Raio: Baseado na sua cidade/localização

**Eventos de Amigos**
- ✅ Ativado: Quando amigos confirmam ou criam eventos
- Útil para: Descobrir o que seus amigos estão fazendo

**Lembretes de Eventos**
- ✅ Ativado: 1h antes e no horário do evento
- **Recomendado:** Deixar ativo para não perder eventos

**Cancelamentos**
- ✅ Ativado: Se evento que você confirmou for cancelado
- **Obrigatório:** Sempre ativo para proteção

#### Social

**Convites de Amizade**
- ✅ Ativado: Quando alguém te adiciona
- ❌ Desativado: Você ainda vê em "Notificações" na app

**Novas Mensagens**
- ✅ Ativado: Mensagens de chat
- Só de pessoas que podem te enviar mensagens (baseado em privacidade)

**Atividade de Amigos**
- ✅ Ativado: Amigos postam em grupos, avaliam eventos, etc.
- Pode ser intenso se você tem muitos amigos ativos

#### Seus Eventos (Organizador)

**Novos Participantes**
- ✅ Ativado: Alguém confirma presença no seu evento
- Útil para: Acompanhar crescimento

**Avaliações Recebidas**
- ✅ Ativado: Após evento, participantes avaliam
- Importante para: Melhorar organização

#### Grupos

**Novos Posts**
- ✅ Ativado: Alguém posta em grupo que você participa
- ⚠️ Pode ser muito se você está em muitos grupos ativos

**Novas Enquetes**
- ✅ Ativado: Enquete criada em grupo
- Útil para: Participar de decisões

**Novos Membros**
- ❌ Geralmente desativado: Não muito relevante
- ✅ Ativar se: Grupo pequeno e você quer conhecer todos

**Comentários nos seus Posts**
- ✅ Ativado: Alguém comenta no seu post
- Importante para: Engajamento

### Configurações de Email

#### Eventos Locais

**Frequência:**
- 📧 **Nunca:** Sem emails sobre eventos
- 📧 **Imediato:** Email para cada evento novo (pode ser muito)
- 📧 **Diário:** Resumo diário (recomendado)
- 📧 **Semanal:** Resumo semanal (menos intrusivo)

**Exemplo de Resumo Diário:**
```
📅 Eventos Hoje na Sua Região

1. Workshop de Fotografia - 14h
2. Corrida no Parque - 18h
3. Show de Jazz - 21h

+ 5 eventos este fim de semana
```

#### Outros Emails

**Eventos de Amigos**
- ✅ Ativado: Quando amigos criam/confirmam eventos
- ❌ Desativado: Apenas notificação push

**Atividade de Amigos**
- ✅ Ativado: Resumos de atividade
- Frequência: Semanal (não configurável)

**Novas Mensagens**
- ❌ Geralmente desativado: Push é melhor
- ✅ Ativar se: Você não usa app frequentemente

**Seus Eventos - Novos Participantes**
- ✅ Ativado: Notificação por email
- Útil se: Você não checa app com frequência

**Seus Eventos - Cancelamento**
- ✅ **Sempre ativo:** Garantir que participantes saibam

## Ativar Push Notifications

### Primeira Vez

Ao acessar a plataforma:
1. Navegador/App solicita permissão
2. Clique em **"Permitir"**
3. Pronto! Notificações ativadas

**Se você bloqueou:**
1. Configurações do navegador
2. Permissões do site
3. Ativar notificações
4. Recarregar página

### Por Navegador

#### Chrome (Desktop)
```
1. Ícone do cadeado na barra de endereço
2. Configurações do site
3. Notificações → Permitir
```

#### Safari (Mac/iOS)
```
1. Safari → Preferências
2. Sites → Notificações
3. Encontre o site → Permitir
```

#### Firefox
```
1. Ícone do cadeado
2. Permissões
3. Receber notificações → Permitir
```

#### Mobile (Android/iOS)
```
1. Configurações do dispositivo
2. Apps → [Nome do Navegador]
3. Notificações → Ativar
```

### Instalar como App (PWA)

Para melhor experiência mobile:

**Android (Chrome):**
```
1. Menu (⋮) → Adicionar à tela inicial
2. Confirmar
3. App aparece na home
4. Notificações funcionam nativamente
```

**iOS (Safari):**
```
1. Botão compartilhar
2. Adicionar à Tela de Início
3. Confirmar
4. Ícone aparece na home
```

## Gerenciar Centro de Notificações

### Na Plataforma

**Ícone de Sino:**
- Topo da tela (desktop)
- Menu superior (mobile)
- Badge com número de não lidas

**Tipos de Notificação:**
```
👥 João Silva enviou solicitação de amizade
   2 horas atrás

🎉 Novo evento: "Workshop de Marketing"
   Amanhã, 14h • 1.2 km de você
   1 dia atrás

💬 Mensagem de Maria: "Oi! Vamos ao evento?"
   5 minutos atrás

✅ Pedro confirmou presença em "Corrida Matinal"
   3 horas atrás
```

**Ações:**
- **Clicar:** Abre conteúdo relacionado
- **Marcar como lida:** Swipe ou ícone
- **Deletar:** Remover notificação

### Limpar Notificações

**Individual:**
- Swipe left → Delete
- Ou clique no X

**Em Massa:**
- Botão **"Marcar todas como lidas"**
- Botão **"Limpar todas"** (apenas lidas)

## Boas Práticas

### Configuração Recomendada

**Para Usuário Ativo:**
```
Push:
✅ Novos eventos locais
✅ Eventos de amigos
✅ Novas mensagens
✅ Lembretes de eventos
❌ Atividade de amigos (muito)
❌ Novos posts em grupos (muito)
✅ Comentários nos seus posts

Email:
📧 Eventos locais: Diário
❌ Eventos de amigos: Desativado (push já notifica)
❌ Novas mensagens: Desativado (push já notifica)
```

**Para Organizador de Eventos:**
```
Tudo acima +
✅ Novos participantes (push + email)
✅ Avaliações recebidas
```

**Para Uso Ocasional:**
```
Push:
✅ Lembretes de eventos
✅ Novas mensagens
❌ Resto desativado

Email:
📧 Eventos locais: Semanal
📧 Lembretes de eventos: Ativado
```

### Evitar Sobrecarga

**Problema:** Muitas notificações = ignore todas

**Solução:**
1. **Seja seletivo:** Ative apenas essenciais
2. **Use resumos:** Email diário/semanal em vez de imediato
3. **Grupos:** Desative posts, mantenha apenas enquetes importantes
4. **Revise:** Ajuste configurações mensalmente

### Não Perder o Importante

**Sempre deixar ativo:**
- ✅ Lembretes de eventos (1h antes)
- ✅ Cancelamentos de eventos
- ✅ Novas mensagens (se você usa chat)
- ✅ Confirmações em seus eventos (se organizador)

## Troubleshooting

### Não estou recebendo notificações push

**Checklist:**
1. ✅ Permissão concedida no navegador?
2. ✅ Notificações ativadas nas configurações da plataforma?
3. ✅ Navegador está atualizado?
4. ✅ Dispositivo tem internet?
5. ✅ Sistema operacional permite notificações?

**Solução:**
1. Desative notificações na plataforma
2. Revogue permissão no navegador
3. Recarregue página
4. Permita notificações novamente
5. Reative nas configurações

### Emails indo para spam

**Solução:**
1. Marque como "Não é spam"
2. Adicione `no-reply@seudominio.com` aos contatos
3. Crie regra de filtro para não ir ao spam

### Recebendo emails duplicados

**Causa:** Múltiplas configurações ativas

**Solução:**
1. Vá em Configurações → Notificações
2. Revise todas opções de email
3. Desative duplicatas
4. Salvar

### Notificações em horários inconvenientes

**Solução:**
- Modo "Não Perturbe" do dispositivo
- Horário comercial (7h-22h) para eventos locais
- Lembretes sempre respeitam horário do evento

## Privacidade

### O que Enviamos

**Push:**
- Título do evento/notificação
- Snippet de texto
- Ação relacionada (link)

**Email:**
- Informações do evento
- Link direto
- Botão de ação

**Não enviamos:**
- ❌ Dados sensíveis
- ❌ Senhas
- ❌ Informações financeiras
- ❌ Localização precisa

### Cancelar Inscrição

**Por Email:**
- Link "Cancelar inscrição" no rodapé
- Desativa TODOS emails de marketing
- Emails transacionais continuam (confirmações, etc.)

**Total:**
- Configurações → Notificações → Desativar tudo
- Ou deletar conta (remove tudo)

## Estatísticas (para você)

Em breve, você poderá ver:
- 📊 Quantas notificações recebeu
- 📈 Taxa de abertura
- ⏰ Horários de maior atividade
- 📱 Dispositivos mais usados

Útil para otimizar suas configurações!

## Perguntas Frequentes

**Q: Posso desativar todas notificações?**  
R: Sim, mas você perderá lembretes importantes. Recomendamos manter pelo menos lembretes de eventos ativos.

**Q: Notificações consomem muita bateria?**  
R: Não! Usamos Firebase que é otimizado para eficiência.

**Q: Posso ter notificações só de certos amigos?**  
R: Atualmente não. É tudo ou nada. Feature planejada para futuro.

**Q: Recebo notificação mesmo com app fechado?**  
R: Sim! Push notifications funcionam em background.

**Q: Posso personalizar som da notificação?**  
R: Depende do dispositivo. Configure no sistema operacional, não na app.

**Q: Há limite de notificações por dia?**  
R: Eventos locais: Máximo 3 por dia. Demais: Sem limite, mas use configurações para controlar.

**Q: Como saber se uma notificação é legítima?**  
R: Todas notificações vêm do domínio oficial. Nunca pedimos dados sensíveis em notificações.

---

**Configuração perfeita = Informado sem sobrecarga! ⚖️**

Ajuste suas preferências até encontrar o equilíbrio ideal para você.
