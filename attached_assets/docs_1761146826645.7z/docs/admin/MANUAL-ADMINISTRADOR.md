# 🛡️ Manual do Administrador

## Índice

1. [Acesso ao Painel Admin](#acesso-ao-painel-admin)
2. [Dashboard e Métricas](#dashboard-e-métricas)
3. [Gerenciamento de Usuários](#gerenciamento-de-usuários)
4. [Gerenciamento de Eventos](#gerenciamento-de-eventos)
5. [Sistema de Moderação](#sistema-de-moderação)
6. [Gestão de Boosts](#gestão-de-boosts)
7. [Categorias](#categorias)
8. [Relatórios e Analytics](#relatórios-e-analytics)

---

## Acesso ao Painel Admin

### Requisitos

Para acessar o painel administrativo, você precisa:
- Conta com role `admin` ou `super_admin`
- Login autenticado

### Níveis de Acesso

**Super Admin:**
- Acesso total ao sistema
- Pode criar/remover admins
- Acesso a configurações críticas
- Gerenciamento de planos de boost

**Admin:**
- Moderação de conteúdo
- Gerenciamento de usuários e eventos
- Visualização de relatórios
- Sem acesso a configurações de sistema

### Primeiro Acesso

Usuário admin padrão (configurado automaticamente):
- **Username:** admin
- **Password:** (Definido em variável de ambiente)
- **Email:** admin@example.com

**IMPORTANTE:** Altere a senha imediatamente após primeiro acesso!

---

## Dashboard e Métricas

### KPIs Principais

**Visão Geral:**
- 👥 **Total de Usuários:** Cadastros totais
- 🎉 **Total de Eventos:** Criados na plataforma
- 📈 **Usuários Ativos (30d):** Login nos últimos 30 dias
- 💰 **Receita Total:** De eventos pagos + boosts
- 📊 **Taxa de Conversão:** Eventos criados / Usuários
- ⭐ **Avaliação Média:** Rating global da plataforma

**Gráficos:**
- Crescimento de usuários (últimos 12 meses)
- Eventos criados por mês
- Receita mensal
- Distribuição por categoria

### Tempo Real

- 🟢 Usuários online agora
- 🎫 Vendas nas últimas 24h
- 🆕 Eventos criados hoje
- 📝 Denúncias pendentes

---

## Gerenciamento de Usuários

### Listagem de Usuários

**Filtros Disponíveis:**
- Nome/Email/Username
- Status: Ativo / Suspenso / Banido
- Role: Usuário / Admin / Super Admin
- Tipo de auth: Replit / Local
- Trust Score (reputação)
- Data de cadastro

**Informações Exibidas:**
- ID do usuário
- Nome completo
- Email (mascarado para privacidade)
- Data de cadastro
- Último acesso
- Total de eventos criados
- Status de moderação
- Trust Score

### Ações em Usuários

**Visualizar Perfil:**
- Informações completas
- Histórico de eventos
- Histórico de moderação
- Transações (se aplicável)

**Editar:**
- Alterar role (Admin/User)
- Atualizar informações básicas
- Resetar senha (envia email)

**Moderar:**
- **Advertir:** Notifica usuário sobre violação
- **Suspender:** Bloqueia temporariamente (define prazo)
- **Banir:** Bloqueia permanentemente
- **Reativar:** Remove suspensão/ban

**Ajustar Trust Score:**
- Aumentar (+10 pontos)
- Diminuir (-10 pontos)
- Resetar para 100 (padrão)

### Histórico do Usuário

**Eventos Criados:**
- Lista completa
- Status (aprovado/rejeitado)
- Participantes
- Receita gerada

**Atividade de Moderação:**
- Eventos rejeitados
- Denúncias recebidas
- Advertências
- Suspensões anteriores

**Transações:**
- Compras de ingressos
- Vendas (como organizador)
- Compras de boost
- Saldo de créditos

---

## Gerenciamento de Eventos

### Listagem de Eventos

**Filtros:**
- Status: Todos / Aprovados / Pendentes / Rejeitados
- Categoria
- Data (futuro/passado)
- Tipo: Gratuito / Pago / Vaquinha
- Privado / Público
- Com boost ativo
- Criador (ID ou nome)

**Ordenação:**
- Mais recentes
- Mais antigos
- Por número de participantes
- Por receita
- Por risk score (moderação)

### Detalhes do Evento

**Informações Completas:**
- Todos os campos do evento
- Criador (link para perfil)
- Participantes confirmados
- Estatísticas de visualização
- Receita (se pago)
- Status de moderação
- Risk score e motivos

**Análise de Moderação:**
Se evento foi flagado:
- 🚩 Palavras/URLs bloqueados encontrados
- 📊 Risk score detalhado
- 🤖 Decisão automática
- 📝 Notas de moderação

### Ações em Eventos

**Aprovar:**
- Se estava pendente/em revisão
- Evento fica visível publicamente

**Rejeitar:**
- Motivo obrigatório
- Notifica criador
- Opções:
  - Spam
  - Informações falsas
  - Conteúdo impróprio
  - Duplicado
  - Outro (texto livre)

**Solicitar Revisão:**
- Para casos ambíguos
- Outro admin deve revisar

**Editar:**
- Corrigir informações
- Atualizar categoria
- Modificar descrição

**Cancelar:**
- Força cancelamento
- Reembolsa ingressos automaticamente
- Notifica todos participantes
- Registra motivo

**Destacar:**
- Marca como evento em destaque
- Aparece em banner principal
- Útil para eventos especiais da plataforma

---

## Sistema de Moderação

### Fila de Moderação

**Eventos Pendentes:**
Lista de eventos aguardando aprovação:
- Ordenados por risk score (maior primeiro)
- Mostra preview: título, descrição, imagem
- Destaque para conteúdo suspeito
- Ações rápidas: Aprovar / Rejeitar

**Denúncias Pendentes:**

**Denúncias de Eventos:**
- ID do evento
- Reportado por (usuário)
- Categoria: Spam / Hate Speech / Illegal / Misleading / Fraud / Inappropriate Image / Other
- Detalhes adicionais
- Data da denúncia
- Status: Pendente / Em Revisão / Resolvido

**Denúncias de Usuários:**
- ID do usuário reportado
- Reportado por
- Categoria: Spam / Harassment / Hate Speech / Impersonation / Inappropriate Content / Fraud / Other
- Detalhes
- Data
- Status

### Processar Denúncia

**Fluxo:**
1. Analise o conteúdo reportado
2. Verifique contexto e histórico
3. Decida ação:
   - **Manter:** Denúncia improcedente
   - **Remover Conteúdo:** Deletar evento/post
   - **Advertir Usuário:** Notificação de violação
   - **Suspender Usuário:** Bloqueio temporário
   - **Banir Usuário:** Bloqueio permanente
4. Adicione notas explicando decisão
5. Sistema notifica reportante e reportado

### Blocklist de Moderação

**Gerenciar Termos Bloqueados:**

Lista de palavras/URLs/padrões que acionam moderação:

**Campos:**
- **Termo:** Palavra, URL ou regex
- **Tipo:** Keyword / URL / Regex
- **Risk Score:** Pontos adicionados se encontrado (1-100)
- **Notas:** Por que foi bloqueado
- **Status:** Ativo / Inativo

**Adicionar Novo:**
```
Termo: casino
Tipo: Keyword
Risk Score: 30
Notas: Possível spam de jogos de azar
```

**Padrões Regex:**
```
Termo: \b\d{3}[-.]?\d{3}[-.]?\d{4}\b
Tipo: Regex
Risk Score: 20
Notas: Detecção de número de telefone
```

**Testar Moderação:**
- Campo de teste
- Insira texto suspeito
- Sistema analisa e mostra risk score
- Útil para calibrar regras

### Trust Score do Usuário

Sistema de reputação automático:

**Como Funciona:**
- Todos começam com 100 pontos
- Ações positivas: +pontos
- Ações negativas: -pontos
- Score < 50: Moderação mais rigorosa
- Score < 20: Suspensão automática

**Eventos que Alteram Score:**

**Aumentam (+):**
- Evento aprovado: +5
- Avaliação 5 estrelas recebida: +3
- Evento bem-sucedido (>80% lotação): +10
- Usuário há 1 ano sem violações: +20

**Diminuem (-):**
- Evento rejeitado: -15
- Denúncia procedente: -25
- Spam detectado: -30
- Cancelamento de evento (sem reembolso): -10

---

## Gestão de Boosts

### Planos de Boost

**Visualizar Planos:**
- Diamante, Ouro, Prata
- Preços (BRL e USD)
- Features
- Status (ativo/inativo)

**Editar Plano:**
- Alterar preço
- Modificar features
- Ajustar número de boosts
- Ativar/desativar

**Criar Novo Plano:**
```
Nome: Platinum
Tier: platinum
Preço BRL: R$ 299,90
Preço USD: $79.90
Total Boosts: 200
Top Boosts: 50
Duração: 60 dias
Features:
  - 200 "subidas" ao longo de 60 dias
  - 50 aparições no topo absoluto
  - Suporte prioritário
  - Badge especial
```

### Boosts Ativos

**Lista de Boosts:**
- Evento promovido
- Plano usado
- Usuário (organizador)
- Status: Ativo / Completado / Cancelado
- Progresso (X/Y boosts usados)
- Próxima "subida" programada
- Data de expiração

**Ações:**
- **Pausar:** Interrompe temporariamente
- **Retomar:** Reativa boost pausado
- **Cancelar:** Encerra boost (sem reembolso)
- **Estender:** Adiciona mais dias/boosts

### Relatório de Boosts

**Métricas:**
- Total de boosts vendidos (este mês)
- Receita de boosts
- Plano mais popular
- Taxa de renovação
- Efetividade (boost → lotação evento)

---

## Categorias

### Gerenciar Categorias

**Estrutura Hierárquica:**
```
Música (categoria pai)
  ├─ Shows (subcategoria)
  ├─ Festivais (subcategoria)
  └─ Karaokê (subcategoria)
```

**Campos:**
- Nome (PT e EN)
- Value (slug único)
- Ícone (Font Awesome class)
- Categoria Pai (se subcategoria)
- Ordem de Exibição

### Adicionar Categoria

1. Clique em **"Nova Categoria"**
2. Preencha:
   ```
   Nome: Tecnologia
   Value: tecnologia
   Ícone: fa-laptop
   Pai: (nenhum)
   Ordem: 10
   ```
3. Salvar

### Adicionar Subcategoria

1. Selecione categoria pai
2. Clique em **"Adicionar Subcategoria"**
3. Preencha:
   ```
   Nome: Inteligência Artificial
   Value: inteligencia-artificial
   Ícone: fa-brain
   Pai: Tecnologia
   Ordem: 1
   ```

### Reorganizar

- Drag & drop para alterar ordem
- Mover subcategoria para outra categoria pai
- Salvar alterações

### Deletar Categoria

**CUIDADO:** Deletar categoria afeta eventos!

**Opções ao deletar:**
1. **Mover eventos para outra categoria:** Selecione destino
2. **Deletar eventos também:** Ação destrutiva!
3. **Cancelar:** Não deleta

---

## Relatórios e Analytics

### Relatório de Usuários

**Filtros:**
- Período (último mês, trimestre, ano, customizado)
- Tipo de auth
- Localização (cidade/estado/país)

**Métricas:**
- Novos cadastros
- Taxa de retenção
- Churn rate
- Usuários ativos diários (DAU)
- Usuários ativos mensais (MAU)

**Exportar:**
- CSV: Dados brutos
- PDF: Relatório formatado

### Relatório de Eventos

**Análises:**
- Eventos criados por período
- Taxa de eventos pagos vs gratuitos
- Distribuição por categoria
- Taxa de lotação média
- Eventos cancelados (% e razões)

**Top Eventos:**
- Mais participantes
- Maior receita
- Melhor avaliado
- Mais visualizações

### Relatório Financeiro

**Receita:**
- Total por período
- Breakdown:
  - Ingressos vendidos
  - Boosts vendidos
  - Por categoria
  - Por região

**Comissões:**
- Total repassado a organizadores
- Taxas Stripe pagas
- Margem da plataforma

**Previsões:**
- Receita projetada próximos meses
- Baseado em tendências históricas

### Relatório de Moderação

**Estatísticas:**
- Eventos aprovados/rejeitados
- Tempo médio de moderação
- Denúncias por categoria
- Taxa de denúncias procedentes
- Usuários banidos/suspensos

**Performance:**
- Eventos auto-aprovados (baixo risk score)
- Eventos que precisaram revisão humana
- Efetividade da blocklist

---

## Configurações do Sistema

*(Apenas Super Admin)*

### Configurações Gerais

**Plataforma:**
- Nome da plataforma
- Logo
- Favicon
- Cores primárias/secundárias

**Email:**
- Remetente padrão
- Templates de email
- Configurações SMTP/SendGrid

**Notificações:**
- Configurar Firebase
- Templates de push notifications
- Horários permitidos para envio

### Configurações de Moderação

**Threshold de Risk Score:**
- < 30: Auto-aprovar
- 30-70: Revisão humana
- > 70: Auto-rejeitar

**Tempo de Revisão:**
- SLA para moderação: 24h
- Escalonar após: 48h sem ação

### Integrações

**Stripe:**
- API Keys
- Webhooks
- Configurações de taxa

**Mapbox:**
- Access Token
- Configurações de mapa

**Firebase:**
- Credentials
- Configuração de push

### Backups

- Frequência de backup
- Retenção (30 dias padrão)
- Restaurar de backup (lista de backups)

---

## Ações em Massa

### Usuários

**Selecionar múltiplos usuários:**
- Enviar email em massa
- Atualizar role
- Suspender/Banir em lote
- Exportar dados

### Eventos

**Selecionar múltiplos eventos:**
- Aprovar em lote
- Rejeitar em lote
- Alterar categoria
- Exportar lista

---

## Logs e Auditoria

### Log de Ações Admin

Rastreamento completo de ações administrativas:

**Registrado:**
- Usuário admin que executou
- Ação realizada
- Entidade afetada (usuário/evento)
- Timestamp
- IP de origem
- Dados antes/depois (changelog)

**Exemplos:**
```
2025-10-20 14:32:10 | admin@exemplo.com | Baniu usuário ID:abc123 | Motivo: Spam recorrente
2025-10-20 14:28:05 | admin@exemplo.com | Aprovou evento ID:xyz789
2025-10-20 14:15:22 | super@exemplo.com | Alterou preço Boost Ouro: R$ 69,90 → R$ 59,90
```

### Auditoria de Moderação

- Total de decisões por admin
- Tempo médio de resposta
- Taxa de reversões (decisão alterada por outro admin)
- Qualidade das decisões (baseado em denúncias posteriores)

---

## Segurança

### Autenticação 2FA

**Para Admins (Obrigatório):**
- Habilitar Google Authenticator
- Códigos de backup
- Renovar a cada 30 dias

### Permissões

**Matriz de Permissões:**

| Ação | User | Admin | Super Admin |
|------|------|-------|-------------|
| Ver dashboard | ❌ | ✅ | ✅ |
| Moderar conteúdo | ❌ | ✅ | ✅ |
| Gerenciar usuários | ❌ | ✅ | ✅ |
| Banir usuários | ❌ | ✅ | ✅ |
| Criar admins | ❌ | ❌ | ✅ |
| Configurações sistema | ❌ | ❌ | ✅ |
| Gerenciar boosts | ❌ | ✅ | ✅ |
| Editar planos boost | ❌ | ❌ | ✅ |
| Ver relatórios | ❌ | ✅ | ✅ |
| Backups | ❌ | ❌ | ✅ |

### Proteção de Dados

- Dados sensíveis mascarados
- Acesso via logs de auditoria
- Conformidade LGPD/GDPR
- Direito ao esquecimento implementado

---

## Boas Práticas

### Moderação

1. **Seja Consistente:** Use mesmos critérios para casos similares
2. **Documente:** Sempre adicione notas explicando decisão
3. **Seja Rápido:** Responda denúncias em <24h
4. **Escale Dúvidas:** Se incerto, marque para revisão
5. **Comunique:** Explique decisões aos usuários

### Gestão de Usuários

1. **Eduque Antes de Punir:** Primeira violação = advertência
2. **Progressivo:** Advertência → Suspensão → Ban
3. **Reversível:** Permita apelações
4. **Transparente:** Explique motivos

### Analytics

1. **Monitore KPIs Diariamente:** Identifique anomalias cedo
2. **Relatórios Semanais:** Para equipe
3. **Análise Mensal:** Tendências e ajustes estratégicos
4. **Tome Decisões Baseadas em Dados:** Não em intuição

---

## Suporte e Escalação

### Suporte ao Usuário

**Canais:**
- Email: suporte@plataforma.com
- Chat em tempo real (horário comercial)
- FAQ / Central de Ajuda

**SLA:**
- Resposta inicial: 4h
- Resolução problemas simples: 24h
- Problemas complexos: 72h

### Escalação de Problemas

**Nível 1 - Suporte Básico:**
- Dúvidas sobre funcionalidades
- Problemas de login
- Orientações gerais

**Nível 2 - Admin:**
- Problemas de moderação
- Disputas entre usuários
- Questões técnicas

**Nível 3 - Super Admin:**
- Problemas de sistema
- Integrações quebradas
- Decisões estratégicas

**Nível 4 - Desenvolvimento:**
- Bugs críticos
- Desenvolvimento de features
- Emergências de sistema

---

## FAQ do Admin

**Q: Como reverter um ban injusto?**  
R: Vá para perfil do usuário → Histórico de Moderação → Remover Ban → Adicionar nota explicando.

**Q: Posso deletar eventos que já aconteceram?**  
R: Não recomendado. Marque como "arquivado" para manter histórico.

**Q: Como lidar com spam massivo?**  
R: Identifique padrão → Adicione à blocklist → Ban em massa dos usuários → Relatório de segurança.

**Q: Posso dar boost gratuito para eventos especiais?**  
R: Sim! Super Admin pode ativar boost sem cobrança para eventos da própria plataforma.

**Q: Como exportar todos os dados de um usuário (LGPD)?**  
R: Perfil do Usuário → Ações → Exportar Dados (envia JSON com tudo por email).

---

**Versão:** 1.0  
**Última Atualização:** Outubro 2025

Para tutoriais de funcionalidades específicas, consulte documentação técnica separada.
