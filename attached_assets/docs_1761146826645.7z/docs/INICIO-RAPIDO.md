# 🚀 Guia de Início Rápido

Bem-vindo à plataforma de gerenciamento de eventos! Este guia vai te ajudar a começar rapidamente.

## 📱 Primeiros Passos

### 1. Criar sua Conta

Você tem duas opções para se registrar:

**Opção A: Login com Replit**
- Clique em "Entrar com Replit"
- Autorize o acesso
- Pronto! Sua conta está criada

**Opção B: Criar conta local**
- Clique em "Criar conta"
- Preencha: nome de usuário, email e senha
- Confirme seu email (verifique sua caixa de entrada)

### 2. Configurar seu Perfil

1. Vá para **Perfil** (ícone no menu inferior)
2. Adicione suas informações:
   - Foto de perfil
   - Bio (até 160 caracteres)
   - Cidade
   - Redes sociais (Instagram, Facebook, etc.)
3. Configure sua privacidade em **Configurações**

### 3. Explorar Eventos

Na tela inicial (**Home**):
- 📍 Veja eventos próximos à sua localização
- 🔍 Use a busca para encontrar eventos específicos
- 🏷️ Filtre por categorias (Música, Esportes, Arte, etc.)
- 📅 Ordene por data

### 4. Participar de um Evento

1. Clique no evento que te interessa
2. Veja todos os detalhes: data, local, descrição, palestrantes
3. Clique em **"Confirmar Presença"**
4. Se houver ingressos pagos:
   - Escolha o tipo de ingresso
   - Complete o pagamento via Stripe
   - Receba seu ingresso com QR Code por email

### 5. Criar seu Primeiro Evento

1. Clique no botão **"+"** no menu inferior
2. Preencha as informações:
   - **Título** e **Descrição**
   - **Data e Hora**
   - **Local** (use o mapa para precisão)
   - **Categoria**
   - **Foto de capa**
3. Configure opções:
   - 💰 Tipo: Gratuito, Pago ou Vaquinha (crowdfunding)
   - 🔒 Público ou Privado
   - 👥 Limite de participantes
   - 🔁 Recorrência (se aplicável)
4. Clique em **"Criar Evento"**

### 6. Conectar-se com Pessoas

**Fazer Amizades:**
- Busque usuários na aba **"Amigos"**
- Envie solicitação de amizade
- Aceite solicitações recebidas

**Chat:**
- Clique em **"Mensagens"** no menu
- Selecione um amigo para conversar
- Envie mensagens em tempo real

### 7. Participar de Grupos

1. Vá para **"Grupos"**
2. Explore grupos por interesse ou cidade
3. Clique em **"Entrar"**
4. Participe das discussões e enquetes

## 🔔 Ativar Notificações

Para não perder nada:

1. Permita notificações quando solicitado
2. Configure suas preferências em **Configurações > Notificações**:
   - Push (instantâneas)
   - Email (diárias ou semanais)

## 💡 Dicas Rápidas

- ⭐ **Avalie eventos:** Ajude outros usuários com suas avaliações
- 🎯 **Use o Boost:** Destaque seu evento investindo em promoção
- 💸 **Ganhe créditos:** Indique amigos e ganhe saldo para boosts
- 📸 **Compartilhe fotos:** Contribua para a galeria colaborativa dos eventos

## ❓ Precisa de Ajuda?

Consulte nossos [manuais completos](./manuais/) ou entre em contato com o suporte.

---

**Próximos Passos:**
- 📖 Leia o [Manual do Usuário Completo](./manuais/MANUAL-USUARIO.md)
- 🎯 Aprenda sobre [Boost de Eventos](./tutoriais/boost-eventos.md)
- 👥 Descubra o [Programa de Referência](./tutoriais/programa-referencia.md)
