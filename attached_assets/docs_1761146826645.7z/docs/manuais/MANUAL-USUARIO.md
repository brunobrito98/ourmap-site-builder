# 📚 Manual Completo do Usuário

## Índice

1. [Introdução](#introdução)
2. [Conta e Perfil](#conta-e-perfil)
3. [Eventos](#eventos)
4. [Social](#social)
5. [Notificações](#notificações)
6. [Pagamentos](#pagamentos)
7. [Privacidade](#privacidade)

---

## Introdução

Bem-vindo ao manual completo da plataforma de eventos! Aqui você encontrará todas as informações necessárias para aproveitar ao máximo todas as funcionalidades.

### O que é a plataforma?

Uma solução completa para:
- 🎟️ Descobrir e participar de eventos
- 📝 Criar e gerenciar seus próprios eventos
- 👥 Conectar-se com pessoas com interesses semelhantes
- 💬 Interagir através de chat e grupos
- 🎯 Promover seus eventos com sistema de boost

---

## Conta e Perfil

### Criação de Conta

#### Replit Auth
- Login rápido e seguro
- Sem necessidade de senha adicional
- Sincronização automática com Replit

#### Conta Local
- Email + senha personalizados
- Verificação de email obrigatória
- Recuperação de senha disponível

### Personalização do Perfil

#### Informações Básicas
- **Nome e Sobrenome**
- **Foto de Perfil:** JPG, PNG ou GIF (até 5MB)
- **Bio:** Até 160 caracteres
- **Localização:** Cidade, estado e país

#### Galeria de Fotos
- Adicione até 4 fotos ao seu perfil
- Mostre seus interesses e personalidade
- Configure visibilidade individual

#### Redes Sociais
Conecte suas redes:
- 📷 Instagram
- 👤 Facebook  
- 🐦 Twitter/X
- 💼 LinkedIn
- 🌐 Website pessoal

### Configurações de Privacidade

Controle quem vê suas informações:

| Informação | Opções de Visibilidade |
|-----------|----------------------|
| Localização | Todos / Conexões / Seguidores / Ninguém |
| Eventos Confirmados | Todos / Conexões / Seguidores / Ninguém |
| Eventos Criados | Todos / Seguidores / Conexões |
| Bio | Todos / Conexões / Seguidores / Ninguém |
| Galeria de Fotos | Todos / Conexões / Seguidores / Ninguém |

#### Privacidade de Mensagens
Escolha quem pode te enviar mensagens:
- **Qualquer pessoa**
- **Apenas quem você segue**
- **Apenas conexões (amigos)**

---

## Eventos

### Descobrir Eventos

#### Tela Inicial (Home)
- **Eventos próximos:** Baseados na sua localização
- **Filtros:** Por categoria, data, preço
- **Busca:** Por nome, local ou palavra-chave
- **Mapa:** Visualização geográfica

#### Categorias Disponíveis

**Principais:**
- 🎵 Música (Shows, Festivais, Karaokê)
- 🏃 Esportes (Corridas, Futebol, Yoga)
- 🎨 Arte & Cultura (Exposições, Teatro, Cinema)
- 🎓 Educação (Workshops, Palestras, Cursos)
- 🍔 Gastronomia (Festivais, Degustações)
- 🌱 Meio Ambiente (Limpeza, Plantio)
- 💼 Networking (Meetups, Conferências)
- 🎮 Jogos & Tecnologia
- 👨‍👩‍👧 Família (Infantil, Piqueniques)
- 🎉 Festas & Social

### Participar de Eventos

#### Eventos Gratuitos
1. Clique no evento
2. Leia os detalhes
3. Clique em "Confirmar Presença"
4. Pronto! Você receberá lembretes

#### Eventos Pagos
1. Escolha o tipo de ingresso
2. Quantidade (se aplicável)
3. Complete o pagamento via Stripe
4. Receba ingresso com QR Code por email
5. Apresente o QR Code no dia do evento

#### Eventos com Vaquinha (Crowdfunding)
- Contribua com o valor que desejar
- Valor mínimo (se definido pelo organizador)
- Acompanhe o progresso da meta
- Sua contribuição pode ser anônima ou pública

#### Lista de Espera
Se o evento estiver lotado:
- Entre na lista de espera
- Receba notificação se abrir vaga
- Aceite a vaga em até 24h

### Criar Eventos

#### Informações Básicas
- **Título:** Descritivo e atrativo
- **Descrição:** Detalhes do evento (markdown suportado)
- **Data e Hora:** Início e fim
- **Local:** Use o mapa para precisão
- **Categoria e Subcategoria**
- **Foto de Capa:** Atraia participantes (mín. 1200x630px)

#### Tipos de Eventos

**Evento Gratuito**
- Sem custos para participantes
- Ideal para eventos comunitários
- Pode ter limite de vagas

**Evento Pago**
- Configure tipos de ingresso
- Preços em BRL (Brasil) ou USD (internacional)
- Receba pagamentos via Stripe
- Tipos de ingresso:
  - **Lote único:** Preço fixo
  - **Lotes progressivos:** Preços aumentam com tempo
  - **Múltiplos tipos:** VIP, Standard, Student, etc.

**Vaquinha (Crowdfunding)**
- Defina meta de arrecadação
- Valor mínimo por contribuição (opcional)
- Acompanhe total arrecadado
- Transparência total para contribuidores

#### Opções Avançadas

**Evento Privado**
- Apenas com link ou convite
- Link compartilhável único
- Controle total de participantes
- Perfeito para eventos corporativos/familiares

**Evento Recorrente**
- Diário, semanal, quinzenal ou mensal
- Configure intervalo personalizado
- Defina data de término
- Gestão unificada de todas ocorrências

**Limite de Participantes**
- Defina capacidade máxima
- Lista de espera automática
- Notificações de vagas disponíveis

**Convidados Especiais**
- Adicione palestrantes, DJs, instrutores
- Foto, nome, bio e função
- Ordem de exibição personalizada

### Gerenciar Eventos

#### Painel do Organizador
- **Participantes:** Veja quem confirmou presença
- **Check-in:** Escaneie QR Codes (eventos pagos)
- **Vendas:** Acompanhe receita e ingressos vendidos
- **Vaquinha:** Veja contribuições e progresso
- **Edição:** Modifique detalhes (notifica participantes)
- **Cancelamento:** Reembolso automático + notificações

#### Galeria de Fotos
- Participantes podem adicionar fotos
- Galeria colaborativa do evento
- Moderação de fotos (opcional)
- Compartilhamento em redes sociais

#### Avaliações
Após o evento, participantes podem:
- Avaliar o evento (1-5 estrelas)
- Avaliar o organizador (1-5 estrelas)
- Deixar comentários
- Ajudar futuros participantes

---

## Social

### Sistema de Amizades

#### Tipos de Conexões
- **Amigos (Conexões):** Vínculo mútuo
- **Seguindo:** Você acompanha alguém
- **Seguidores:** Pessoas que te acompanham

#### Fazer Amizades
1. Encontre usuários:
   - Pela busca
   - Em eventos que participou
   - Sugestões baseadas em interesses
2. Envie solicitação de amizade
3. Aguarde aceitação
4. Conexão estabelecida!

### Chat Privado

#### Recursos
- Mensagens em tempo real
- Histórico completo
- Notificações instantâneas
- Marcação de leitura

#### Configurações de Privacidade
Controle quem pode te enviar mensagens:
- Qualquer pessoa
- Apenas quem você segue
- Apenas amigos (conexões)

### Grupos Temáticos

#### O que são Grupos?
Comunidades organizadas por interesse ou localização:
- 🎸 Grupos de interesse (Música, Arte, Esportes)
- 🌍 Grupos por cidade/região
- 💼 Grupos profissionais
- 🎯 Grupos de hobbies

#### Participar de Grupos
1. Navegue por grupos
2. Filtre por interesse ou cidade
3. Clique em "Entrar no Grupo"
4. Participe das discussões!

#### Funcionalidades do Grupo

**Feed de Discussões**
- Crie posts
- Comente em discussões
- Curta contribuições
- Compartilhe eventos relacionados

**Enquetes**
- Vote em decisões do grupo
- Crie suas próprias enquetes
- Veja resultados em tempo real
- Opções múltiplas suportadas

**Eventos do Grupo**
- Eventos exclusivos para membros
- Notificações prioritárias
- Comunidade engajada

---

## Notificações

### Tipos de Notificações

#### Notificações Push (Instantâneas)
- 👥 Novas solicitações de amizade
- 🎉 Novos eventos na sua área
- 📅 Lembretes de eventos (1h antes e no horário)
- ✅ Confirmações de presença nos seus eventos
- 💬 Novas mensagens
- ⭐ Avaliações recebidas
- 👥 Atividade de grupos
- ❌ Cancelamento de eventos

#### Notificações por Email

**Eventos Locais:**
- **Nunca**
- **Imediatamente**
- **Resumo Diário** (1 email por dia)
- **Resumo Semanal** (1 email por semana)

**Outras Notificações:**
- Eventos de amigos
- Atividade de amigos
- Novas mensagens
- Confirmações nos seus eventos
- Cancelamentos de eventos

### Configurar Notificações

1. Vá para **Configurações**
2. Selecione **Notificações**
3. Ative/desative por tipo
4. Escolha frequência de emails
5. Salve alterações

**Dica:** Deixe lembretes de eventos ativos para não perder nada!

---

## Pagamentos

### Stripe - Processamento Seguro

Todos os pagamentos são processados pelo Stripe, líder mundial em segurança de pagamentos.

#### Métodos Aceitos
- 💳 Cartões de crédito (Visa, Mastercard, Amex, Elo)
- 💳 Cartões de débito
- 🏦 PIX (Brasil)
- 🔒 Todos os dados criptografados

### Comprar Ingressos

1. Selecione tipo e quantidade de ingressos
2. Revise o carrinho
3. Clique em "Pagar"
4. Complete informações de pagamento
5. Confirmação instantânea
6. Receba ingresso por email com QR Code

### Vendedor de Ingressos

#### Configuração
- Conecte conta Stripe (one-time)
- Configure tipos de ingressos
- Defina preços (BRL ou USD automático)
- Ative vendas

#### Recebimento
- Pagamentos diretos na sua conta Stripe
- Taxas Stripe padrão aplicadas
- Relatórios detalhados
- Reembolsos automáticos em cancelamentos

### Contribuir em Vaquinhas

1. Escolha valor da contribuição
2. Decida se quer aparecer publicamente
3. Complete pagamento
4. Acompanhe progresso da meta
5. Organizador recebe quando meta é atingida

---

## Sistema de Boost

### O que é Boost?

Sistema de promoção paga para destacar seu evento:
- 📈 Aparece primeiro nas buscas
- 🔝 Destaque na tela inicial
- 👀 Maior visibilidade
- 📊 Mais participantes

### Planos Disponíveis

#### 🥈 Prata
**R$ 29,90 / $9.90**
- 20 "subidas" ao longo de 7 dias
- Destaque moderado
- Ideal para eventos locais

#### 🥇 Ouro  
**R$ 69,90 / $19.90**
- 50 "subidas" ao longo de 14 dias
- 10 aparições no topo
- Destaque forte
- Ideal para eventos médios

#### 💎 Diamante
**R$ 149,90 / $39.90**
- 100 "subidas" ao longo de 30 dias
- 30 aparições no topo
- Máximo destaque
- Ideal para grandes eventos

### Como Funciona

1. **Compre o Plano:** Escolha e pague via Stripe
2. **Distribuição Automática:** Sistema "sobe" seu evento automaticamente ao longo do período
3. **Maior Alcance:** Seu evento aparece para muito mais pessoas
4. **Acompanhe:** Veja estatísticas de visualizações e confirmações

### Pagar com Créditos

Use saldo de créditos do programa de referência para pagar boosts!

---

## Programa de Referência

### Como Funciona

1. **Compartilhe seu Link Único**
2. **Amigos se Cadastram**
3. **Você Ganha R$ 10,00 de Crédito**
4. **Use em Boosts de Eventos**

### Onde Encontrar seu Link

1. Vá para **Perfil**
2. Clique em **Programa de Referência**
3. Copie seu link único
4. Compartilhe com amigos!

### Seus Créditos

- Visualize saldo atual
- Histórico de transações
- Use para pagar boosts
- Sem validade!

---

## Privacidade e Segurança

### Seus Dados

- ✅ Criptografia em todas comunicações
- ✅ Senhas protegidas com hash bcrypt
- ✅ Dados pessoais nunca compartilhados
- ✅ Conformidade com LGPD/GDPR

### Controles de Privacidade

Configure individualmente:
- Visibilidade do perfil
- Quem pode ver sua localização
- Quem vê seus eventos
- Quem pode te enviar mensagens
- Visibilidade da galeria de fotos

### Moderação de Conteúdo

- Sistema automático de detecção
- Análise de eventos criados
- Denúncias de usuários
- Equipe de moderação humana
- Ação rápida contra violações

### Reportar Problemas

**Reportar Evento:**
- Spam
- Informações falsas
- Conteúdo impróprio
- Fraude
- Imagem inadequada

**Reportar Usuário:**
- Assédio
- Spam
- Discurso de ódio
- Falsificação de identidade
- Conteúdo impróprio

---

## Perguntas Frequentes

### Geral

**Q: A plataforma é gratuita?**  
R: Sim! Criar conta, descobrir e participar de eventos gratuitos não tem custo. Eventos pagos e sistema de boost têm taxas.

**Q: Posso usar no celular?**  
R: Sim! A plataforma é totalmente responsiva e funciona em qualquer dispositivo.

**Q: Como recebo notificações no celular?**  
R: Ative notificações quando solicitado pelo navegador. Para app nativo, instale via Progressive Web App (PWA).

### Eventos

**Q: Posso editar um evento depois de criado?**  
R: Sim! Todos participantes confirmados receberão notificação das mudanças.

**Q: Posso cancelar um evento?**  
R: Sim. Ingressos pagos são reembolsados automaticamente e todos participantes são notificados.

**Q: Qual a taxa para eventos pagos?**  
R: Você paga apenas as taxas padrão do Stripe. Sem taxa adicional da plataforma.

### Pagamentos

**Q: É seguro pagar na plataforma?**  
R: Absolutamente! Usamos Stripe, processador usado por milhões de empresas mundialmente.

**Q: Como recebo o dinheiro dos ingressos?**  
R: Direto na sua conta Stripe conectada. Disponível em 2-7 dias úteis.

**Q: Posso ter reembolso?**  
R: Sim, se o organizador cancelar o evento. Política de reembolso do organizador se aplica em outros casos.

### Privacidade

**Q: Posso esconder minha localização?**  
R: Sim! Configure em Privacidade > Localização > Ninguém.

**Q: Como impedir mensagens indesejadas?**  
R: Configurações > Privacidade de Mensagens > Apenas Conexões.

### Suporte

**Q: Como entro em contato com suporte?**  
R: Use o formulário de contato em Configurações > Ajuda e Suporte.

**Q: Posso excluir minha conta?**  
R: Sim. Configurações > Conta > Excluir Conta. Ação irreversível.

---

## Glossário

- **Boost:** Promoção paga para destaque de eventos
- **Conexões:** Amigos mútuos na plataforma
- **Crowdfunding/Vaquinha:** Arrecadação coletiva para viabilizar evento
- **Organizador:** Criador do evento
- **QR Code:** Código para check-in em eventos pagos
- **Stripe:** Processador de pagamentos
- **Vaga:** Espaço disponível em evento com limite de participantes

---

**Versão:** 1.0  
**Última Atualização:** Outubro 2025

Para tutoriais específicos, visite a [pasta de tutoriais](../tutoriais/).
